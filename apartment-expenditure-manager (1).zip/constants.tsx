import React from 'react';

export const APP_NAME = "Apartment Ledger";
export const APARTMENT_NAME_FOR_RECEIPT = APP_NAME;
export const WATER_UNIT_COST = 170;
export const MANAGER_NAME = "Stephen Kibira";

export const IconDashboard: React.FC<{className?: string}> = ({ className }) => (
  <svg className={className} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" />
  </svg>
);

export const IconTenants: React.FC<{className?: string}> = ({ className }) => (
  <svg className={className} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 016-6h6m6 3h-3m3 0h3m-3 0v-3m0 3v3M3 21v-1a6 6 0 016-6h6m3 6H9m12 0a9 9 0 00-9-9m9 9c0-5.042-3.768-9.192-8.544-10.516M3 15v-1a6 6 0 016-6h1M3 15h.01M21 15h-.01M12 8a3 3 0 100-6 3 3 0 000 6z" />
  </svg>
);

export const IconExpenditures: React.FC<{className?: string}> = ({ className }) => (
  <svg className={className} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 9V7a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2m2 4h10a2 2 0 002-2v-6a2 2 0 00-2-2H9a2 2 0 00-2 2v6a2 2 0 002 2zm7-5a2 2 0 11-4 0 2 2 0 014 0z" />
  </svg>
);

export const IconWaterDrop: React.FC<{className?: string}> = ({ className }) => (
  <svg className={className} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" d="M7.5 16.5A5.25 5.25 0 0012.75 22m0 0a5.25 5.25 0 005.25-5.25M12.75 22V7.227A5.283 5.283 0 0012 7.125C11.06 7.125 10.154 7.424 9.375 7.916m3.375 14.084c.143-.02.284-.043.425-.067M9.375 7.916A5.25 5.25 0 007.5 16.5m0 0H6.375m1.125 0V12m0 4.5A5.25 5.25 0 012.25 12c0-1.605.723-3.046 1.875-4.007M2.25 12h1.125m0 0V7.875m0 4.125A5.25 5.25 0 007.5 16.5M12.75 22A5.25 5.25 0 0018 16.5m0 0h1.125m-1.125 0V12m0 4.5a5.25 5.25 0 01-5.25 4.5M18 12c0-1.605-.723-3.046-1.875-4.007M21.75 12h-1.125m0 0V7.875m0 4.125A5.25 5.25 0 0018 16.5" />
  </svg>
);


export const IconPlus: React.FC<{className?: string}> = ({ className }) => (
  <svg className={className} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
  </svg>
);

export const IconEdit: React.FC<{className?: string}> = ({ className }) => (
  <svg className={className} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
  </svg>
);

export const IconTrash: React.FC<{className?: string}> = ({ className }) => (
  <svg className={className} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
  </svg>
);

export const IconClose: React.FC<{className?: string}> = ({ className }) => (
    <svg className={className} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />
    </svg>
);

export const IconMenu: React.FC<{className?: string}> = ({ className }) => (
  <svg className={className} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
  </svg>
);

export const IconFilter: React.FC<{className?: string}> = ({ className }) => (
  <svg className={className} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" d="M12 3c-1.2 0-2.3.4-3.2 1.1L5.2 7.7c-.6.6-.9 1.3-.9 2.1V10c0 .2 0 .3.1.5l2.7 5.3c.9 1.7 2.6 2.9 4.6 3.1v1.1c0 .6.4 1 1 1s1-.4 1-1v-1.1c2-.2 3.7-1.3 4.6-3.1l2.7-5.3c0-.1.1-.3.1-.5v-.2c0-.8-.3-1.6-.9-2.1l-3.6-3.6C14.3 3.4 13.2 3 12 3zm0 1.5c.7 0 1.4.2 2 .5l3.6 3.6c.3.3.4.7.4 1.1V10c0 .1 0 .1 0 .1l-2.7 5.3c-.7 1.3-2 2.2-3.5 2.4v-9c0-.8-.7-1.5-1.5-1.5S9 9.2 9 10v2.3C7.5 12 6.2 11.1 5.5 9.8L2.8 4.5c0 0 0-.1 0-.1V8.2c0-.4.1-.7.4-1.1l3.6-3.6c.6-.3 1.2-.5 1.9-.5z" />
  </svg>
);

export const IconReceipt: React.FC<{className?: string}> = ({ className }) => (
  <svg className={className} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
  </svg>
);

export const IconPdf: React.FC<{className?: string}> = ({ className }) => (
  <svg className={className} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" d="M19.5 14.25v-2.625a3.375 3.375 0 00-3.375-3.375h-1.5A1.125 1.125 0 0113.5 7.125v-1.5a3.375 3.375 0 00-3.375-3.375H8.25m2.25 0H5.625c-.621 0-1.125.504-1.125 1.125v17.25c0 .621.504 1.125 1.125 1.125h12.75c.621 0 1.125-.504 1.125-1.125V11.25a9 9 0 00-9-9z" />
    <path strokeLinecap="round" strokeLinejoin="round" d="M15.75 5.25v2.625a1.125 1.125 0 001.125 1.125H19.5M15.75 10.5H18M4.5 10.5h3.75M4.5 15h3.75M10.5 15h6.75" />
  </svg>
);
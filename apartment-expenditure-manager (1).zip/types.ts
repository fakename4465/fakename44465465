export enum ExpenditureCategory {
  RENT = 'Rent',
  WATER = 'Water Bill',
  ELECTRICITY = 'Electricity Bill',
  GAS = 'Gas Bill',
  INTERNET = 'Internet Bill',
  MAINTENANCE = 'Maintenance', // This can be for general property maintenance not tied to specific tenant rent
  PROPERTY_TAX = 'Property Tax',
  INSURANCE = 'Insurance',
  OTHER = 'Other',
}

export interface Tenant {
  id: string;
  name: string;
  block: string; 
  houseNumber: string; 
  moveInDate: string; 
  rentAmount?: number; // Default base rent for the tenant
  maintenanceFee?: number; // Default maintenance fee for the tenant
}

export enum PaymentStatus {
  PAID = 'Paid',
  PENDING = 'Pending',
  OVERDUE = 'Overdue'
}

export interface Expenditure {
  id:string;
  tenantId?: string; 
  date: string; 
  category: ExpenditureCategory;
  amount: number; // Total amount
  description: string;
  isRecurring: boolean;
  paymentMethod?: string;
  paymentStatus?: PaymentStatus;

  // Water Bill Specific
  previousWaterReading?: number;
  currentWaterReading?: number;
  waterUnitsConsumed?: number;

  // Rent Specific
  baseRentPortion?: number;
  maintenancePortion?: number;
}
# Apartment Expenditure Manager - Installation Guide

This guide will help you set up and run the Apartment Expenditure Manager application on your local machine.

## Prerequisites

- A modern web browser (e.g., Chrome, Firefox, Edge, Safari).
- A text editor or IDE if you plan to modify the code (e.g., VS Code).
- Node.js and npm (if you plan to use a local development server for more complex setups, though not strictly required for basic `index.html` opening).

## Setup Instructions

1.  **Download or Clone the Application Files:**
    *   If you have a ZIP file, extract all the files to a new folder on your computer.
    *   If you're using Git, clone the repository:
        ```bash
        git clone <repository_url>
        cd apartment-expenditure-manager
        ```

2.  **API Key Configuration:**
    This application requires a Google Gemini API key to function if any AI-powered features are implemented (currently, the base app does not use Gemini, but this is a placeholder for future enhancements).
    *   The application expects the API key to be available as an environment variable named `API_KEY`.
    *   **For browser-based execution (opening `index.html` directly):**
        Since frontend JavaScript running directly in the browser cannot securely access system environment variables in the same way Node.js can, you would typically:
        *   **During Development (Not for Production):** You might temporarily hardcode it or use a local development server that can inject it. However, the provided code structure `process.env.API_KEY` implies a build step or server-side environment.
        *   **If a build system (like Vite, Create React App) were in use:** You would typically use a `.env` file (e.g., `.env.local`) and the build tool would handle making it available as `process.env.API_KEY` or `import.meta.env.VITE_API_KEY`.
    *   **For the current simple setup (opening `index.html`):** The `process.env.API_KEY` will likely be undefined. If AI features are added and are essential, a more robust setup (like a simple Node.js backend or a build process) would be needed to manage the API key securely. For now, features relying on this will not work without further setup.

3.  **Running the Application:**

    *   **Simple Method (Directly in Browser):**
        Navigate to the folder where you extracted/cloned the application files.
        Locate the `index.html` file and open it with your web browser.
        (Right-click on `index.html` -> Open with -> Choose your browser).

    *   **Using a Local Development Server (Recommended for development):**
        If you have Node.js and `http-server` (or any other simple HTTP server) installed, you can serve the files locally. This can help avoid potential issues with file pathing or CORS if you start making more complex requests.
        ```bash
        # Install http-server globally (if you haven't already)
        npm install -g http-server

        # Navigate to your project directory in the terminal
        cd path/to/your/apartment-expenditure-manager

        # Start the server
        http-server
        ```
        Then open the URL provided by `http-server` (usually `http://localhost:8080`) in your browser.

## Application Structure

-   `index.html`: The main HTML file.
-   `index.tsx`: The main TypeScript file that bootstraps the React application.
-   `App.tsx`: The root React component containing the application layout and routing.
-   `components/`: Contains reusable React components.
-   `pages/`: Contains components that represent different pages/views of the application.
-   `hooks/`: Contains custom React hooks.
-   `types.ts`: Defines TypeScript types and interfaces used throughout the application.
-   `constants.tsx`: Stores application-wide constants, like icons or static configuration.
-   `metadata.json`: Contains metadata about the application.

## Data Storage

The application uses the browser's `localStorage` to persist tenant and expenditure data. This means the data is stored locally in your browser and will remain available unless you clear your browser's site data.

## Troubleshooting

-   **App doesn't load:**
    *   Check the browser's developer console (usually by pressing F12) for any error messages.
    *   Ensure all files were extracted correctly and `index.html` can access `index.tsx` (and other related files).
-   **Data not saving:**
    *   Ensure your browser has `localStorage` enabled and is not in a private/incognito mode that clears data on exit (unless intended).
    *   Check the developer console for any errors related to `localStorage`.

Enjoy managing your apartment expenditures!

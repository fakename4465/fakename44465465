
import React, { useMemo } from 'react';
import { Tenant, Expenditure } from '../types';
import ExpenditureCategoryPieChart from '../components/charts/ExpenditureCategoryPieChart';
import MonthlyExpenditureBarChart from '../components/charts/MonthlyExpenditureBarChart';
import { IconTenants, IconExpenditures, IconDashboard, APP_NAME } from '../constants';

interface DashboardPageProps {
  tenants: Tenant[];
  expenditures: Expenditure[];
}

const DashboardPage: React.FC<DashboardPageProps> = ({ tenants, expenditures }) => {
  const totalExpenditureAmount = useMemo(() => {
    return expenditures.reduce((sum, exp) => sum + exp.amount, 0);
  }, [expenditures]);

  const averageExpenditure = useMemo(() => {
    if (expenditures.length === 0) return 0;
    // Calculate average monthly expenditure based on unique months with data
    const monthlyTotals: { [key: string]: number } = {};
    expenditures.forEach(exp => {
      const monthYear = new Date(exp.date).toLocaleDateString('en-US', { year: 'numeric', month: '2-digit' });
      monthlyTotals[monthYear] = (monthlyTotals[monthYear] || 0) + exp.amount;
    });
    const monthsWithExpenditures = Object.keys(monthlyTotals).length;
    return monthsWithExpenditures > 0 ? totalExpenditureAmount / monthsWithExpenditures : 0;
  }, [expenditures, totalExpenditureAmount]);

  const recentExpenditures = useMemo(() => {
    return [...expenditures]
      .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
      .slice(0, 5);
  }, [expenditures]);

  const tenantMap = useMemo(() => {
    return tenants.reduce((acc, tenant) => {
      acc[tenant.id] = tenant.name;
      return acc;
    }, {} as Record<string, string>);
  }, [tenants]);


  return (
    <div className="space-y-8">
      <h1 className="text-3xl font-semibold text-gray-800">Dashboard</h1>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <div className="bg-white p-6 rounded-xl shadow-lg hover:shadow-xl transition-shadow duration-300">
          <div className="flex items-center text-primary">
            <IconTenants className="h-8 w-8 mr-3" />
            <h2 className="text-xl font-semibold">Total Tenants</h2>
          </div>
          <p className="text-4xl font-bold text-gray-800 mt-2">{tenants.length}</p>
        </div>
        <div className="bg-white p-6 rounded-xl shadow-lg hover:shadow-xl transition-shadow duration-300">
          <div className="flex items-center text-secondary">
             <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="h-8 w-8 mr-3">
                <path strokeLinecap="round" strokeLinejoin="round" d="M2.25 18.75a60.07 60.07 0 0 1 15.797 2.101c.727.198 1.453-.342 1.453-1.096V18.75M3.75 4.5v.75A.75.75 0 0 1 3 6h-.75m0 0v-.75A.75.75 0 0 1 2.25 4.5h.75m0 0H21m-9 12.75h5.25M12 4.5h9" />
            </svg>
            <h2 className="text-xl font-semibold">Total Expenditures</h2>
          </div>
          <p className="text-4xl font-bold text-gray-800 mt-2">${totalExpenditureAmount.toFixed(2)}</p>
        </div>
        <div className="bg-white p-6 rounded-xl shadow-lg hover:shadow-xl transition-shadow duration-300">
          <div className="flex items-center text-accent">
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="h-8 w-8 mr-3">
                <path strokeLinecap="round" strokeLinejoin="round" d="M2.25 18L9 11.25l4.306 4.307a11.95 11.95 0 0 1 5.814-5.519l2.74-1.22m0 0l-5.94-2.281m5.94 2.28L21 4.997M3.75 21h16.5M4.5 3h15M5.25 3v18m13.5-18v18" />
            </svg>
            <h2 className="text-xl font-semibold">Avg. Monthly Expense</h2>
          </div>
          <p className="text-4xl font-bold text-gray-800 mt-2">${averageExpenditure.toFixed(2)}</p>
        </div>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white p-6 rounded-xl shadow-lg">
          <h3 className="text-xl font-semibold text-gray-700 mb-4">Expenditures by Category</h3>
          <ExpenditureCategoryPieChart expenditures={expenditures} />
        </div>
        <div className="bg-white p-6 rounded-xl shadow-lg">
          <h3 className="text-xl font-semibold text-gray-700 mb-4">Monthly Expenditures (Last 12 Months)</h3>
          <MonthlyExpenditureBarChart expenditures={expenditures} />
        </div>
      </div>
      
      {/* Recent Expenditures List */}
      {recentExpenditures.length > 0 && (
        <div className="bg-white p-6 rounded-xl shadow-lg">
          <h3 className="text-xl font-semibold text-gray-700 mb-4">Recent Expenditures</h3>
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date</th>
                  <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Category</th>
                  <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Description</th>
                  <th className="px-4 py-2 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Amount</th>
                  <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Tenant</th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {recentExpenditures.map(exp => (
                  <tr key={exp.id}>
                    <td className="px-4 py-2 whitespace-nowrap text-sm text-gray-500">{new Date(exp.date).toLocaleDateString()}</td>
                    <td className="px-4 py-2 whitespace-nowrap text-sm text-gray-500">{exp.category}</td>
                    <td className="px-4 py-2 whitespace-normal text-sm text-gray-900 max-w-xs truncate" title={exp.description}>{exp.description}</td>
                    <td className="px-4 py-2 whitespace-nowrap text-sm text-gray-700 text-right">${exp.amount.toFixed(2)}</td>
                    <td className="px-4 py-2 whitespace-nowrap text-sm text-gray-500">{exp.tenantId ? tenantMap[exp.tenantId] || 'N/A' : 'General'}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
       {tenants.length === 0 && expenditures.length === 0 && (
         <div className="text-center py-10 bg-white rounded-xl shadow-lg">
            <IconDashboard className="h-16 w-16 mx-auto text-gray-400 mb-4" />
            <p className="text-gray-600 text-xl font-semibold">Welcome to {APP_NAME}!</p>
            <p className="text-gray-500 mt-2">Start by adding tenants or recording expenditures.</p>
        </div>
      )}
    </div>
  );
};

export default DashboardPage;

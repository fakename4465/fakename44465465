
import React, { useState, useMemo } from 'react';
import { Expenditure, Tenant, ExpenditureCategory, PaymentStatus } from '../types';
import Modal from '../components/common/Modal';
import ExpenditureForm from '../components/expenditures/ExpenditureForm';
import ReceiptDisplay from '../components/receipts/ReceiptDisplay'; 
import { IconPlus, IconEdit, IconTrash, IconExpenditures, IconFilter, IconReceipt, APARTMENT_NAME_FOR_RECEIPT } from '../constants';

interface ExpendituresPageProps {
  expenditures: Expenditure[];
  addExpenditure: (expenditure: Omit<Expenditure, 'id'>) => void;
  deleteExpenditure: (expenditureId: string) => void;
  updateExpenditure: (expenditure: Expenditure) => void;
  tenants: Tenant[];
}

const ExpendituresPage: React.FC<ExpendituresPageProps> = ({ expenditures, addExpenditure, deleteExpenditure, updateExpenditure, tenants }) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingExpenditure, setEditingExpenditure] = useState<Expenditure | null>(null);
  
  const [filterTenantId, setFilterTenantId] = useState<string>('');
  const [filterCategory, setFilterCategory] = useState<string>('');
  const [showFilters, setShowFilters] = useState(false);

  const [receiptExpenditure, setReceiptExpenditure] = useState<Expenditure | null>(null);

  const tenantMap = useMemo(() => {
    return tenants.reduce((acc, tenant) => {
      acc[tenant.id] = tenant; 
      return acc;
    }, {} as Record<string, Tenant>);
  }, [tenants]);

  const handleAddExpenditure = (expenditureData: Omit<Expenditure, 'id'> | Expenditure) => {
     if ('id' in expenditureData) {
      updateExpenditure(expenditureData as Expenditure);
    } else {
      addExpenditure(expenditureData as Omit<Expenditure, 'id'>);
    }
    setIsModalOpen(false);
    setEditingExpenditure(null);
  };

  const openAddModal = () => {
    setEditingExpenditure(null);
    setIsModalOpen(true);
  };

  const openEditModal = (expenditure: Expenditure) => {
    setEditingExpenditure(expenditure);
    setIsModalOpen(true);
  };

  const handleDeleteExpenditure = (expenditureId: string) => {
    if (window.confirm('Are you sure you want to delete this expenditure?')) {
      deleteExpenditure(expenditureId);
    }
  };

  const openReceiptModal = (exp: Expenditure) => {
    setReceiptExpenditure(exp);
  };

  const closeReceiptModal = () => {
    setReceiptExpenditure(null);
  };
  
  const filteredExpenditures = useMemo(() => {
    return expenditures
      .filter(exp => filterTenantId ? exp.tenantId === filterTenantId : true)
      .filter(exp => filterCategory ? exp.category === filterCategory : true)
      .sort((a,b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  }, [expenditures, filterTenantId, filterCategory]);

  const totalFilteredAmount = useMemo(() => {
    return filteredExpenditures.reduce((sum, exp) => sum + exp.amount, 0);
  }, [filteredExpenditures]);

  const clearFilters = () => {
    setFilterTenantId('');
    setFilterCategory('');
  };

  const getTenantDisplayInfo = (tenantId?: string): string => {
    if (!tenantId || !tenantMap[tenantId]) return 'General';
    const tenant = tenantMap[tenantId];
    return `${tenant.name} (Block ${tenant.block}, House ${tenant.houseNumber})`;
  };
  
  const getTenantNameForReceipt = (tenantId?: string): string | undefined => {
    if (!tenantId || !tenantMap[tenantId]) return undefined;
    return tenantMap[tenantId].name;
  };
  
  const getTenantUnitForReceipt = (tenantId?: string): string | undefined => {
    if (!tenantId || !tenantMap[tenantId]) return undefined;
    const tenant = tenantMap[tenantId];
    return `Block ${tenant.block}, House ${tenant.houseNumber}`;
  };

  const getReceiptTitle = (category?: ExpenditureCategory): string => {
    if (category === ExpenditureCategory.WATER) return "Water Bill Receipt";
    if (category === ExpenditureCategory.RENT) return "Rent Receipt";
    return "Transaction Receipt";
  };

  return (
    <div className="container mx-auto">
      <div className="mb-6">
        <div className="flex flex-col sm:flex-row justify-between items-center mb-2">
            <h1 className="text-3xl font-semibold text-gray-800 flex items-center mb-4 sm:mb-0">
            <IconExpenditures className="h-8 w-8 mr-3 text-primary" /> Expenditures
            </h1>
            <div className="flex space-x-2">
                <button
                    onClick={() => setShowFilters(!showFilters)}
                    className="bg-gray-200 hover:bg-gray-300 text-gray-700 font-semibold py-2 px-4 rounded-lg shadow-md hover:shadow-lg transition-all duration-200 flex items-center"
                    aria-expanded={showFilters}
                    aria-controls="filters-panel"
                    aria-label={showFilters ? "Hide Filters" : "Show Filters"}
                >
                    <IconFilter className="h-5 w-5 mr-2"/> {showFilters ? 'Hide Filters' : 'Show Filters'}
                </button>
                <button
                    onClick={openAddModal}
                    className="bg-primary hover:bg-primary-dark text-white font-semibold py-2 px-4 rounded-lg shadow-md hover:shadow-lg transition-all duration-200 flex items-center"
                    aria-label="Add New Expenditure"
                >
                    <IconPlus className="h-5 w-5 mr-2" /> Add Expenditure
                </button>
            </div>
        </div>
        {showFilters && (
            <div id="filters-panel" className="bg-white p-4 rounded-lg shadow-md my-4 transition-all duration-300 ease-in-out">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 items-end">
                    <div>
                        <label htmlFor="filterTenant" className="block text-sm font-medium text-gray-700">Filter by Tenant</label>
                        <select
                            id="filterTenant"
                            value={filterTenantId}
                            onChange={(e) => setFilterTenantId(e.target.value)}
                            className="mt-1 block w-full px-3 py-2 border border-gray-300 bg-white rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary sm:text-sm"
                        >
                            <option value="">All Tenants</option>
                            {tenants.map(tenant => (
                                <option key={tenant.id} value={tenant.id}>
                                    {tenant.name} (Block {tenant.block}, House {tenant.houseNumber})
                                </option>
                            ))}
                        </select>
                    </div>
                    <div>
                        <label htmlFor="filterCategory" className="block text-sm font-medium text-gray-700">Filter by Category</label>
                        <select
                            id="filterCategory"
                            value={filterCategory}
                            onChange={(e) => setFilterCategory(e.target.value)}
                            className="mt-1 block w-full px-3 py-2 border border-gray-300 bg-white rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary sm:text-sm"
                        >
                            <option value="">All Categories</option>
                            {Object.values(ExpenditureCategory).map(cat => (
                                <option key={cat} value={cat}>{cat}</option>
                            ))}
                        </select>
                    </div>
                    <button
                        onClick={clearFilters}
                        className="bg-gray-500 hover:bg-gray-600 text-white font-semibold py-2 px-4 rounded-lg shadow transition-colors h-fit"
                        aria-label="Clear all filters"
                    >
                        Clear Filters
                    </button>
                </div>
            </div>
        )}
      </div>

      {filteredExpenditures.length === 0 ? (
        <div className="text-center py-10">
            <IconExpenditures className="h-16 w-16 mx-auto text-gray-400 mb-4" />
            <p className="text-gray-500 text-xl">No expenditures found.</p>
            {expenditures.length > 0 && <p className="text-gray-400 mt-2">Try adjusting your filters or add a new expenditure.</p>}
            {expenditures.length === 0 && <p className="text-gray-400 mt-2">Click "Add Expenditure" to get started.</p>}
        </div>
      ) : (
        <div className="bg-white shadow-xl rounded-lg overflow-hidden">
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Category</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Description</th>
                  <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Amount</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Tenant</th>
                   <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                  <th scope="col" className="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {filteredExpenditures.map((exp) => (
                  <tr key={exp.id} className="hover:bg-gray-50 transition-colors">
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{new Date(exp.date).toLocaleDateString()}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{exp.category}</td>
                    <td className="px-6 py-4 whitespace-normal text-sm text-gray-900 max-w-xs truncate" title={exp.description}>{exp.description}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-700 text-right">${exp.amount.toFixed(2)}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{getTenantDisplayInfo(exp.tenantId)}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm">
                        <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                            exp.paymentStatus === PaymentStatus.PAID ? 'bg-green-100 text-green-800' : 
                            exp.paymentStatus === PaymentStatus.PENDING ? 'bg-yellow-100 text-yellow-800' : 
                            'bg-red-100 text-red-800'
                        }`}>
                            {exp.paymentStatus || PaymentStatus.PENDING}
                        </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-center">
                      {(exp.category === ExpenditureCategory.WATER || exp.category === ExpenditureCategory.RENT) && exp.paymentStatus === PaymentStatus.PAID && (
                        <button onClick={() => openReceiptModal(exp)} className="text-green-600 hover:text-green-800 p-1 rounded focus:outline-none focus:ring-2 focus:ring-green-400 mr-2" aria-label={`Generate receipt for ${exp.description}`}>
                           <IconReceipt className="h-5 w-5" />
                        </button>
                      )}
                      <button onClick={() => openEditModal(exp)} className="text-primary-dark hover:text-primary p-1 rounded focus:outline-none focus:ring-2 focus:ring-primary-light" aria-label={`Edit expenditure ${exp.description}`}>
                        <IconEdit className="h-5 w-5" />
                      </button>
                      <button onClick={() => handleDeleteExpenditure(exp.id)} className="text-red-600 hover:text-red-800 ml-2 p-1 rounded focus:outline-none focus:ring-2 focus:ring-red-400" aria-label={`Delete expenditure ${exp.description}`}>
                        <IconTrash className="h-5 w-5" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
               <tfoot className="bg-gray-50">
                <tr>
                    <td colSpan={3} className="px-6 py-3 text-right text-sm font-semibold text-gray-700 uppercase">Total Filtered:</td>
                    <td className="px-6 py-3 text-right text-sm font-semibold text-gray-700">${totalFilteredAmount.toFixed(2)}</td>
                    <td colSpan={3} className="px-6 py-3"></td>
                </tr>
              </tfoot>
            </table>
          </div>
        </div>
      )}

      <Modal isOpen={isModalOpen} onClose={() => { setIsModalOpen(false); setEditingExpenditure(null);}} title={editingExpenditure ? "Edit Expenditure" : "Add New Expenditure"} size="lg">
        <ExpenditureForm 
            onSubmit={handleAddExpenditure} 
            onClose={() => { setIsModalOpen(false); setEditingExpenditure(null);}} 
            initialData={editingExpenditure}
            tenants={tenants}
        />
      </Modal>
      
      {receiptExpenditure && (
         <Modal 
            isOpen={!!receiptExpenditure} 
            onClose={closeReceiptModal} 
            title={getReceiptTitle(receiptExpenditure.category)} 
            size="lg"
         >
            <ReceiptDisplay
                expenditure={receiptExpenditure}
                tenantName={getTenantNameForReceipt(receiptExpenditure.tenantId)}
                tenantUnitInfo={getTenantUnitForReceipt(receiptExpenditure.tenantId)}
                issuerName={APARTMENT_NAME_FOR_RECEIPT}
                onClose={closeReceiptModal} 
                receiptTitle={getReceiptTitle(receiptExpenditure.category)}
            />
        </Modal>
      )}

    </div>
  );
};

export default ExpendituresPage;
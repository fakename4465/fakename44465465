import React, { useState } from 'react';
import { Tenant } from '../types';
import Modal from '../components/common/Modal';
import TenantForm from '../components/tenants/TenantForm';
import { IconPlus, IconEdit, IconTrash, IconTenants } from '../constants';

interface TenantsPageProps {
  tenants: Tenant[];
  addTenant: (tenant: Omit<Tenant, 'id'>) => void;
  deleteTenant: (tenantId: string) => void;
  updateTenant: (tenant: Tenant) => void;
}

const TenantsPage: React.FC<TenantsPageProps> = ({ tenants, addTenant, deleteTenant, updateTenant }) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingTenant, setEditingTenant] = useState<Tenant | null>(null);

  const handleAddTenant = (tenantData: Omit<Tenant, 'id'> | Tenant) => {
    if ('id' in tenantData) { 
      updateTenant(tenantData as Tenant);
    } else {
      addTenant(tenantData as Omit<Tenant, 'id'>);
    }
    setIsModalOpen(false);
    setEditingTenant(null);
  };

  const openAddModal = () => {
    setEditingTenant(null);
    setIsModalOpen(true);
  };

  const openEditModal = (tenant: Tenant) => {
    setEditingTenant(tenant);
    setIsModalOpen(true);
  };

  const handleDeleteTenant = (tenantId: string) => {
    if (window.confirm('Are you sure you want to delete this tenant? This will also delete their associated expenditures.')) {
      deleteTenant(tenantId);
    }
  };

  const sortedTenants = [...tenants].sort((a, b) => {
    if (a.block.toLowerCase() < b.block.toLowerCase()) return -1;
    if (a.block.toLowerCase() > b.block.toLowerCase()) return 1;
    const houseNumA = parseInt(a.houseNumber.match(/\d+/)?.[0] || '0');
    const houseNumB = parseInt(b.houseNumber.match(/\d+/)?.[0] || '0');
    if (houseNumA < houseNumB) return -1;
    if (houseNumA > houseNumB) return 1;
    return a.houseNumber.localeCompare(b.houseNumber);
  });


  return (
    <div className="container mx-auto">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-semibold text-gray-800 flex items-center">
          <IconTenants className="h-8 w-8 mr-3 text-primary" /> Tenants
        </h1>
        <button
          onClick={openAddModal}
          className="bg-primary hover:bg-primary-dark text-white font-semibold py-2 px-4 rounded-lg shadow-md hover:shadow-lg transition-all duration-200 flex items-center"
          aria-label="Add New Tenant"
        >
          <IconPlus className="h-5 w-5 mr-2" /> Add Tenant
        </button>
      </div>

      {sortedTenants.length === 0 ? (
        <div className="text-center py-10">
          <IconTenants className="h-16 w-16 mx-auto text-gray-400 mb-4" />
          <p className="text-gray-500 text-xl">No tenants found.</p>
          <p className="text-gray-400 mt-2">Click "Add Tenant" to get started.</p>
        </div>
      ) : (
        <div className="bg-white shadow-xl rounded-lg overflow-hidden">
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Name</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Block</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">House No.</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Move-in Date</th>
                  <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Base Rent</th>
                  <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Maint. Fee</th>
                  <th scope="col" className="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {sortedTenants.map((tenant) => (
                  <tr key={tenant.id} className="hover:bg-gray-50 transition-colors">
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{tenant.name}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{tenant.block}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{tenant.houseNumber}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{new Date(tenant.moveInDate).toLocaleDateString()}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 text-right">{tenant.rentAmount ? `$${tenant.rentAmount.toFixed(2)}` : 'N/A'}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 text-right">{tenant.maintenanceFee ? `$${tenant.maintenanceFee.toFixed(2)}` : 'N/A'}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-center">
                      <button onClick={() => openEditModal(tenant)} className="text-primary-dark hover:text-primary p-1 rounded focus:outline-none focus:ring-2 focus:ring-primary-light" aria-label={`Edit tenant ${tenant.name}`}>
                        <IconEdit className="h-5 w-5" />
                      </button>
                      <button onClick={() => handleDeleteTenant(tenant.id)} className="text-red-600 hover:text-red-800 ml-3 p-1 rounded focus:outline-none focus:ring-2 focus:ring-red-400" aria-label={`Delete tenant ${tenant.name}`}>
                        <IconTrash className="h-5 w-5" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      <Modal isOpen={isModalOpen} onClose={() => { setIsModalOpen(false); setEditingTenant(null);}} title={editingTenant ? "Edit Tenant" : "Add New Tenant"}>
        <TenantForm 
            onSubmit={handleAddTenant} 
            onClose={() => { setIsModalOpen(false); setEditingTenant(null);}} 
            initialData={editingTenant}
        />
      </Modal>
    </div>
  );
};

export default TenantsPage;
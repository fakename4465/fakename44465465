import React, { useState, useMemo } from 'react';
import { Expenditure, Tenant, ExpenditureCategory, PaymentStatus } from '../types';
import Modal from '../components/common/Modal';
import ReceiptDisplay from '../components/receipts/ReceiptDisplay';
import { IconWaterDrop, IconPdf, IconEdit, APARTMENT_NAME_FOR_RECEIPT } from '../constants';

interface WaterPaymentsPageProps {
  expenditures: Expenditure[];
  tenants: Tenant[];
  updateExpenditure: (expenditure: Expenditure) => void;
}

const WaterPaymentsPage: React.FC<WaterPaymentsPageProps> = ({ expenditures, tenants, updateExpenditure }) => {
  const [receiptExpenditure, setReceiptExpenditure] = useState<Expenditure | null>(null);
  const [editingStatusExpenditure, setEditingStatusExpenditure] = useState<Expenditure | null>(null);
  const [isStatusModalOpen, setIsStatusModalOpen] = useState(false);
  const [currentPaymentStatusInModal, setCurrentPaymentStatusInModal] = useState<PaymentStatus>(PaymentStatus.PENDING);

  const tenantMap = useMemo(() => {
    return tenants.reduce((acc, tenant) => {
      acc[tenant.id] = tenant;
      return acc;
    }, {} as Record<string, Tenant>);
  }, [tenants]);

  const waterBills = useMemo(() => {
    return expenditures
      .filter(exp => exp.category === ExpenditureCategory.WATER)
      .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  }, [expenditures]);

  const openReceiptModal = (exp: Expenditure) => {
    setReceiptExpenditure(exp);
  };

  const closeReceiptModal = () => {
    setReceiptExpenditure(null);
  };
  
  const openEditStatusModal = (exp: Expenditure) => {
    setEditingStatusExpenditure(exp);
    setCurrentPaymentStatusInModal(exp.paymentStatus || PaymentStatus.PENDING);
    setIsStatusModalOpen(true);
  };

  const handleStatusUpdate = () => {
    if (editingStatusExpenditure) {
      updateExpenditure({ ...editingStatusExpenditure, paymentStatus: currentPaymentStatusInModal });
    }
    setIsStatusModalOpen(false);
    setEditingStatusExpenditure(null);
  };

  const getTenantDisplayInfo = (tenantId?: string): string => {
    if (!tenantId || !tenantMap[tenantId]) return 'General';
    const tenant = tenantMap[tenantId];
    return `${tenant.name} (Block ${tenant.block}, House ${tenant.houseNumber})`;
  };
  
  const getTenantNameForReceipt = (tenantId?: string): string | undefined => {
    return tenantId && tenantMap[tenantId] ? tenantMap[tenantId].name : undefined;
  };
  
  const getTenantUnitForReceipt = (tenantId?: string): string | undefined => {
    if (!tenantId || !tenantMap[tenantId]) return undefined;
    const tenant = tenantMap[tenantId];
    return `Block ${tenant.block}, House ${tenant.houseNumber}`;
  };

  return (
    <div className="container mx-auto">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-semibold text-gray-800 flex items-center">
          <IconWaterDrop className="h-8 w-8 mr-3 text-primary" /> Water Bill Payments & Receipts
        </h1>
      </div>

      {waterBills.length === 0 ? (
        <div className="text-center py-10">
          <IconWaterDrop className="h-16 w-16 mx-auto text-gray-400 mb-4" />
          <p className="text-gray-500 text-xl">No water bills recorded yet.</p>
          <p className="text-gray-400 mt-2">Add water bills from the Expenditures page.</p>
        </div>
      ) : (
        <div className="bg-white shadow-xl rounded-lg overflow-hidden">
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Tenant</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Bill Date</th>
                  <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Prev. Read</th>
                  <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Curr. Read</th>
                  <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Units</th>
                  <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Amount</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                  <th scope="col" className="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {waterBills.map((exp) => (
                  <tr key={exp.id} className="hover:bg-gray-50 transition-colors">
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-700">{getTenantDisplayInfo(exp.tenantId)}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{new Date(exp.date).toLocaleDateString()}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 text-right">{exp.previousWaterReading?.toFixed(2) ?? 'N/A'}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 text-right">{exp.currentWaterReading?.toFixed(2) ?? 'N/A'}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 text-right">{exp.waterUnitsConsumed?.toFixed(2) ?? 'N/A'}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-700 text-right">${exp.amount.toFixed(2)}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm">
                      <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                        exp.paymentStatus === PaymentStatus.PAID ? 'bg-green-100 text-green-800' : 
                        exp.paymentStatus === PaymentStatus.PENDING ? 'bg-yellow-100 text-yellow-800' : 
                        'bg-red-100 text-red-800' // For OVERDUE
                      }`}>
                        {exp.paymentStatus || PaymentStatus.PENDING}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-center">
                      <button 
                        onClick={() => openEditStatusModal(exp)} 
                        className="text-blue-600 hover:text-blue-800 p-1 rounded focus:outline-none focus:ring-2 focus:ring-blue-400 mr-2" 
                        aria-label={`Edit payment status for ${exp.description}`}
                      >
                        <IconEdit className="h-5 w-5" />
                      </button>
                      {exp.paymentStatus === PaymentStatus.PAID && (
                        <button 
                            onClick={() => openReceiptModal(exp)} 
                            className="text-green-600 hover:text-green-800 p-1 rounded focus:outline-none focus:ring-2 focus:ring-green-400" 
                            aria-label={`Generate PDF receipt for ${exp.description}`}
                        >
                           <IconPdf className="h-5 w-5" />
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {receiptExpenditure && (
         <Modal isOpen={!!receiptExpenditure} onClose={closeReceiptModal} title="Water Bill PDF Receipt" size="lg">
            <ReceiptDisplay
                expenditure={receiptExpenditure}
                tenantName={getTenantNameForReceipt(receiptExpenditure.tenantId)}
                tenantUnitInfo={getTenantUnitForReceipt(receiptExpenditure.tenantId)}
                issuerName={APARTMENT_NAME_FOR_RECEIPT}
                onClose={closeReceiptModal}
                receiptTitle="Water Bill Receipt"
            />
        </Modal>
      )}
      
      {editingStatusExpenditure && (
        <Modal isOpen={isStatusModalOpen} onClose={() => setIsStatusModalOpen(false)} title="Update Payment Status">
          <div className="space-y-4">
            <p>Tenant: <span className="font-semibold">{getTenantDisplayInfo(editingStatusExpenditure.tenantId)}</span></p>
            <p>Bill Date: <span className="font-semibold">{new Date(editingStatusExpenditure.date).toLocaleDateString()}</span></p>
            <p>Amount: <span className="font-semibold">${editingStatusExpenditure.amount.toFixed(2)}</span></p>
            <div>
              <label htmlFor="paymentStatusModal" className="block text-sm font-medium text-gray-700">Payment Status</label>
              <select
                id="paymentStatusModal"
                value={currentPaymentStatusInModal}
                onChange={(e) => setCurrentPaymentStatusInModal(e.target.value as PaymentStatus)}
                className="mt-1 block w-full px-3 py-2 border border-gray-300 bg-white rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary sm:text-sm"
              >
                {Object.values(PaymentStatus).map(status => (
                  <option key={status} value={status}>{status}</option>
                ))}
              </select>
            </div>
            <div className="flex justify-end space-x-3 pt-2">
              <button
                type="button"
                onClick={() => setIsStatusModalOpen(false)}
                className="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 hover:bg-gray-200 border border-gray-300 rounded-md shadow-sm"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleStatusUpdate}
                className="px-4 py-2 text-sm font-medium text-white bg-primary hover:bg-primary-dark rounded-md shadow-sm"
              >
                Update Status
              </button>
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
};

export default WaterPaymentsPage;
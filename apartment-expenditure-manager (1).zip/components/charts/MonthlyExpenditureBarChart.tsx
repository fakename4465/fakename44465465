
import React from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { Expenditure } from '../../types';

interface ChartData {
  month: string;
  total: number;
}

interface MonthlyExpenditureBarChartProps {
  expenditures: Expenditure[];
}

const MonthlyExpenditureBarChart: React.FC<MonthlyExpenditureBarChartProps> = ({ expenditures }) => {
  const monthlyData: { [key: string]: number } = expenditures.reduce((acc, exp) => {
    const monthYear = new Date(exp.date).toLocaleDateString('en-US', { year: 'numeric', month: 'short' });
    acc[monthYear] = (acc[monthYear] || 0) + exp.amount;
    return acc;
  }, {} as { [key: string]: number });

  const data: ChartData[] = Object.entries(monthlyData)
    .map(([month, total]) => ({ month, total }))
    .sort((a,b) => new Date(a.month).getTime() - new Date(b.month).getTime()); // Sort by month chronologically

  // Show last 12 months, or fewer if less data exists
  const displayData = data.slice(-12);

  if (displayData.length === 0) {
    return <p className="text-center text-gray-500 py-4">No monthly expenditure data to display in chart.</p>;
  }

  return (
    <ResponsiveContainer width="100%" height={400}>
      <BarChart data={displayData} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
        <CartesianGrid strokeDasharray="3 3" />
        <XAxis dataKey="month" />
        <YAxis tickFormatter={(value) => `$${value}`} />
        <Tooltip formatter={(value: number) => `$${value.toFixed(2)}`} />
        <Legend />
        <Bar dataKey="total" fill="#3b82f6" name="Total Expenditures" />
      </BarChart>
    </ResponsiveContainer>
  );
};

export default MonthlyExpenditureBarChart;
    
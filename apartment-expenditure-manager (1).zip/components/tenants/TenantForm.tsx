import React, { useState, useEffect } from 'react';
import { Tenant } from '../../types';

interface TenantFormProps {
  onSubmit: (tenant: Omit<Tenant, 'id'> | Tenant) => void;
  onClose: () => void;
  initialData?: Tenant | null;
}

const TenantForm: React.FC<TenantFormProps> = ({ onSubmit, onClose, initialData }) => {
  const [name, setName] = useState('');
  const [block, setBlock] = useState('');
  const [houseNumber, setHouseNumber] = useState('');
  const [moveInDate, setMoveInDate] = useState('');
  const [rentAmount, setRentAmount] = useState<string>('');
  const [maintenanceFee, setMaintenanceFee] = useState<string>('');

  useEffect(() => {
    if (initialData) {
      setName(initialData.name);
      setBlock(initialData.block);
      setHouseNumber(initialData.houseNumber);
      setMoveInDate(initialData.moveInDate);
      setRentAmount(initialData.rentAmount?.toString() || '');
      setMaintenanceFee(initialData.maintenanceFee?.toString() || '');
    } else {
      setMoveInDate(new Date().toISOString().split('T')[0]);
      setBlock(''); 
      setHouseNumber('');
      setName('');
      setRentAmount('');
      setMaintenanceFee('');
    }
  }, [initialData]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !block || !houseNumber || !moveInDate) {
        alert("Name, Block, House Number, and Move-in Date are required.");
        return;
    }
    const parsedRentAmount = rentAmount ? parseFloat(rentAmount) : undefined;
    const parsedMaintenanceFee = maintenanceFee ? parseFloat(maintenanceFee) : undefined;

    if (rentAmount && (isNaN(parsedRentAmount!) || parsedRentAmount! < 0)) {
        alert("Rent Amount must be a valid positive number.");
        return;
    }
    if (maintenanceFee && (isNaN(parsedMaintenanceFee!) || parsedMaintenanceFee! < 0)) {
        alert("Maintenance Fee must be a valid positive number.");
        return;
    }

    const tenantData = { 
        name, 
        block, 
        houseNumber, 
        moveInDate,
        rentAmount: parsedRentAmount,
        maintenanceFee: parsedMaintenanceFee,
    };

    if (initialData) {
        onSubmit({ ...tenantData, id: initialData.id });
    } else {
        onSubmit(tenantData as Omit<Tenant, 'id'>);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div>
        <label htmlFor="tenantName" className="block text-sm font-medium text-gray-700">Full Name</label>
        <input
          type="text"
          id="tenantName"
          value={name}
          onChange={(e) => setName(e.target.value)}
          required
          className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary sm:text-sm"
          aria-label="Tenant Full Name"
        />
      </div>
      <div>
        <label htmlFor="tenantBlock" className="block text-sm font-medium text-gray-700">Block</label>
        <input
          type="text"
          id="tenantBlock"
          value={block}
          onChange={(e) => setBlock(e.target.value)}
          required
          placeholder="e.g., A, B, Main"
          className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary sm:text-sm"
          aria-label="Tenant Block"
        />
      </div>
      <div>
        <label htmlFor="tenantHouseNumber" className="block text-sm font-medium text-gray-700">House Number</label>
        <input
          type="text"
          id="tenantHouseNumber"
          value={houseNumber}
          onChange={(e) => setHouseNumber(e.target.value)}
          required
          placeholder="e.g., 101, G-02, Apt 5B"
          className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary sm:text-sm"
          aria-label="Tenant House Number"
        />
      </div>
      <div>
        <label htmlFor="moveInDate" className="block text-sm font-medium text-gray-700">Move-in Date</label>
        <input
          type="date"
          id="moveInDate"
          value={moveInDate}
          onChange={(e) => setMoveInDate(e.target.value)}
          required
          className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary sm:text-sm"
          aria-label="Tenant Move-in Date"
        />
      </div>
      <div>
        <label htmlFor="rentAmount" className="block text-sm font-medium text-gray-700">Default Base Rent (Optional)</label>
        <input
          type="number"
          id="rentAmount"
          value={rentAmount}
          onChange={(e) => setRentAmount(e.target.value)}
          min="0"
          step="any"
          placeholder="e.g., 5000"
          className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary sm:text-sm"
          aria-label="Default Base Rent"
        />
      </div>
      <div>
        <label htmlFor="maintenanceFee" className="block text-sm font-medium text-gray-700">Default Maintenance Fee (Optional)</label>
        <input
          type="number"
          id="maintenanceFee"
          value={maintenanceFee}
          onChange={(e) => setMaintenanceFee(e.target.value)}
          min="0"
          step="any"
          placeholder="e.g., 500"
          className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary sm:text-sm"
          aria-label="Default Maintenance Fee"
        />
      </div>
      <div className="flex justify-end space-x-3 pt-2">
        <button
          type="button"
          onClick={onClose}
          className="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 hover:bg-gray-200 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-500 transition-colors"
        >
          Cancel
        </button>
        <button
          type="submit"
          className="px-4 py-2 text-sm font-medium text-white bg-primary hover:bg-primary-dark border border-transparent rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-dark transition-colors"
        >
          {initialData ? 'Save Changes' : 'Add Tenant'}
        </button>
      </div>
    </form>
  );
};

export default TenantForm;
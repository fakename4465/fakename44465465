import React, { useState, useEffect, useCallback } from 'react';
import { Expenditure, ExpenditureCategory, Tenant, PaymentStatus } from '../../types';
import { WATER_UNIT_COST } from '../../constants';

interface ExpenditureFormProps {
  onSubmit: (expenditure: Omit<Expenditure, 'id'> | Expenditure) => void;
  onClose: () => void;
  tenants: Tenant[];
  initialData?: Expenditure | null;
}

const ExpenditureForm: React.FC<ExpenditureFormProps> = ({ onSubmit, onClose, tenants, initialData }) => {
  const [date, setDate] = useState('');
  const [category, setCategory] = useState<ExpenditureCategory>(ExpenditureCategory.OTHER);
  const [amount, setAmount] = useState<number | string>('');
  const [description, setDescription] = useState('');
  const [tenantId, setTenantId] = useState<string | undefined>(undefined);
  const [isRecurring, setIsRecurring] = useState(false);
  const [paymentMethod, setPaymentMethod] = useState('');
  const [paymentStatus, setPaymentStatus] = useState<PaymentStatus>(PaymentStatus.PENDING);

  // Water Bill Specific
  const [previousWaterReading, setPreviousWaterReading] = useState<number | string>('');
  const [currentWaterReading, setCurrentWaterReading] = useState<number | string>('');
  const [waterUnitsConsumed, setWaterUnitsConsumed] = useState<number | undefined>(undefined);

  // Rent Specific
  const [baseRentPortion, setBaseRentPortion] = useState<number | string>('');
  const [maintenancePortion, setMaintenancePortion] = useState<number | string>('');
  
  const selectedTenant = tenants.find(t => t.id === tenantId);

  const resetCategorySpecificFields = () => {
    setPreviousWaterReading('');
    setCurrentWaterReading('');
    setWaterUnitsConsumed(undefined);
    setBaseRentPortion('');
    setMaintenancePortion('');
  };

  const calculateTotalAmount = useCallback(() => {
    if (category === ExpenditureCategory.WATER) {
      const prevReading = parseFloat(previousWaterReading as string);
      const currReading = parseFloat(currentWaterReading as string);
      if (!isNaN(prevReading) && !isNaN(currReading) && currReading >= prevReading) {
        const units = currReading - prevReading;
        setWaterUnitsConsumed(units);
        setAmount(units * WATER_UNIT_COST);
        const monthYear = new Date(date || Date.now()).toLocaleDateString('en-US', { month: 'long', year: 'numeric' });
        if (!initialData?.description) { // Only auto-set description for new entries or if not already set
             setDescription(`Water Bill - ${monthYear} (Units: ${units.toFixed(2)}, Prev: ${prevReading}, Curr: ${currReading})`);
        }
      } else {
        setWaterUnitsConsumed(undefined);
        // setAmount(''); // Allow manual input if readings invalid
      }
    } else if (category === ExpenditureCategory.RENT) {
      const base = parseFloat(baseRentPortion as string);
      const maint = parseFloat(maintenancePortion as string);
      let totalRent = 0;
      if (!isNaN(base) && base >= 0) totalRent += base;
      if (!isNaN(maint) && maint >= 0) totalRent += maint;
      setAmount(totalRent);
      const monthYear = new Date(date || Date.now()).toLocaleDateString('en-US', { month: 'long', year: 'numeric' });
      if (!initialData?.description) { // Only auto-set description for new entries or if not already set
          let desc = `Rent - ${monthYear}`;
          if (selectedTenant) desc += ` for ${selectedTenant.name}`;
          if(!isNaN(maint) && maint > 0) desc += ` (incl. Maintenance)`;
          setDescription(desc);
      }
    }
  }, [category, previousWaterReading, currentWaterReading, date, baseRentPortion, maintenancePortion, initialData, selectedTenant]);


  useEffect(() => {
    if (initialData) {
      setDate(initialData.date);
      setCategory(initialData.category);
      setAmount(initialData.amount);
      setDescription(initialData.description);
      setTenantId(initialData.tenantId);
      setIsRecurring(initialData.isRecurring);
      setPaymentMethod(initialData.paymentMethod || '');
      setPaymentStatus(initialData.paymentStatus || PaymentStatus.PAID);
      
      setPreviousWaterReading(initialData.previousWaterReading?.toString() || '');
      setCurrentWaterReading(initialData.currentWaterReading?.toString() || '');
      setWaterUnitsConsumed(initialData.waterUnitsConsumed);
      
      setBaseRentPortion(initialData.baseRentPortion?.toString() || '');
      setMaintenancePortion(initialData.maintenancePortion?.toString() || '');
    } else {
       setDate(new Date().toISOString().split('T')[0]);
       setCategory(ExpenditureCategory.WATER); 
       setPaymentStatus(PaymentStatus.PENDING);
       resetCategorySpecificFields();
       setAmount('');
       setDescription('');
       setTenantId(undefined);
       setIsRecurring(false);
       setPaymentMethod('');
    }
  }, [initialData]);

  useEffect(() => {
    calculateTotalAmount();
  }, [calculateTotalAmount]);

  useEffect(() => {
    // Pre-fill rent fields when tenant changes and category is RENT
    if (category === ExpenditureCategory.RENT && selectedTenant && !initialData) { // only prefill for new forms or if not editing
        setBaseRentPortion(selectedTenant.rentAmount?.toString() || '');
        setMaintenancePortion(selectedTenant.maintenanceFee?.toString() || '');
    }
  }, [category, selectedTenant, initialData]);


  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    const numericAmount = parseFloat(amount as string);
    if (!date || !category || isNaN(numericAmount) || numericAmount < 0 || !description) {
        alert("Date, Category, valid Total Amount, and Description are required.");
        return;
    }
    
    let expenditureData: Partial<Expenditure> = {
        date, 
        category, 
        amount: numericAmount, 
        description, 
        tenantId: tenantId === "GENERAL" || tenantId === "" ? undefined : tenantId, 
        isRecurring,
        paymentMethod,
        paymentStatus,
    };

    if (category === ExpenditureCategory.WATER) {
        const prevReading = parseFloat(previousWaterReading as string);
        const currReading = parseFloat(currentWaterReading as string);

        if (isNaN(prevReading) || isNaN(currReading) || prevReading < 0 || currReading < 0) {
            alert("Previous and Current water readings must be non-negative numbers.");
            return;
        }
        if (currReading < prevReading) {
            alert("Current water reading cannot be less than previous water reading.");
            return;
        }
        expenditureData = {
            ...expenditureData,
            previousWaterReading: prevReading,
            currentWaterReading: currReading,
            waterUnitsConsumed: currReading - prevReading,
            amount: (currReading - prevReading) * WATER_UNIT_COST, 
        };
    } else if (category === ExpenditureCategory.RENT) {
        const base = parseFloat(baseRentPortion as string);
        const maint = parseFloat(maintenancePortion as string);
        
        if ((baseRentPortion && (isNaN(base) || base < 0)) || (maintenancePortion && (isNaN(maint) || maint < 0))) {
            alert("Base Rent and Maintenance Fee portions must be valid non-negative numbers if provided.");
            return;
        }
        expenditureData = {
            ...expenditureData,
            baseRentPortion: !isNaN(base) && base >=0 ? base : undefined,
            maintenancePortion: !isNaN(maint) && maint >=0 ? maint : undefined,
            // Amount is already calculated and set in expenditureData
        };
    }


    if (initialData) {
        onSubmit({ ...initialData, ...expenditureData });
    } else {
        onSubmit(expenditureData as Omit<Expenditure, 'id'>);
    }
  };
  
  const formInputClasses = "mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary sm:text-sm";


  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div>
        <label htmlFor="expDate" className="block text-sm font-medium text-gray-700">Date</label>
        <input
          type="date"
          id="expDate"
          value={date}
          onChange={(e) => setDate(e.target.value)}
          required
          className={formInputClasses}
        />
      </div>
      <div>
        <label htmlFor="expCategory" className="block text-sm font-medium text-gray-700">Category</label>
        <select
          id="expCategory"
          value={category}
          onChange={(e) => {
            const newCategory = e.target.value as ExpenditureCategory;
            setCategory(newCategory);
            resetCategorySpecificFields(); // Clear specific fields
            setAmount(''); // Clear amount, will be recalculated or manually entered
            if (newCategory === ExpenditureCategory.RENT && selectedTenant && !initialData) {
                setBaseRentPortion(selectedTenant.rentAmount?.toString() || '');
                setMaintenancePortion(selectedTenant.maintenanceFee?.toString() || '');
            }
          }}
          required
          className={`${formInputClasses} bg-white`}
        >
          {Object.values(ExpenditureCategory).map(cat => (
            <option key={cat} value={cat}>{cat}</option>
          ))}
        </select>
      </div>

      <div>
        <label htmlFor="expTenant" className="block text-sm font-medium text-gray-700">Tenant (Optional)</label>
        <select
          id="expTenant"
          value={tenantId || "GENERAL"}
          onChange={(e) => {
            const newTenantId = e.target.value === "GENERAL" ? undefined : e.target.value;
            setTenantId(newTenantId);
            // If category is RENT and a new tenant is selected, update rent portions
            const newlySelectedTenant = tenants.find(t => t.id === newTenantId);
            if (category === ExpenditureCategory.RENT && newlySelectedTenant && !initialData) {
                setBaseRentPortion(newlySelectedTenant.rentAmount?.toString() || '');
                setMaintenancePortion(newlySelectedTenant.maintenanceFee?.toString() || '');
            } else if (category === ExpenditureCategory.RENT && !newlySelectedTenant && !initialData) {
                setBaseRentPortion('');
                setMaintenancePortion('');
            }
          }}
          className={`${formInputClasses} bg-white`}
        >
          <option value="GENERAL">General / Not Tenant Specific</option>
          {tenants.map(t => (
            <option key={t.id} value={t.id}>
              {t.name} (Block {t.block}, House {t.houseNumber})
            </option>
          ))}
        </select>
      </div>

      {/* Category Specific Fields */}
      {category === ExpenditureCategory.WATER && (
        <>
          <div>
            <label htmlFor="prevWaterReading" className="block text-sm font-medium text-gray-700">Previous Water Reading</label>
            <input type="number" id="prevWaterReading" value={previousWaterReading} onChange={(e) => setPreviousWaterReading(e.target.value)} required min="0" step="any" className={formInputClasses} />
          </div>
          <div>
            <label htmlFor="currWaterReading" className="block text-sm font-medium text-gray-700">Current Water Reading</label>
            <input type="number" id="currWaterReading" value={currentWaterReading} onChange={(e) => setCurrentWaterReading(e.target.value)} required min={Number(previousWaterReading) >= 0 ? previousWaterReading : 0} step="any" className={formInputClasses} />
          </div>
          {waterUnitsConsumed !== undefined && (
             <p className="text-sm text-gray-600">Units Consumed: {waterUnitsConsumed.toFixed(2)} (Rate: ${WATER_UNIT_COST}/unit)</p>
          )}
        </>
      )}

      {category === ExpenditureCategory.RENT && (
        <>
          <div>
            <label htmlFor="baseRentPortion" className="block text-sm font-medium text-gray-700">Base Rent Portion</label>
            <input type="number" id="baseRentPortion" value={baseRentPortion} onChange={(e) => setBaseRentPortion(e.target.value)} min="0" step="any" className={formInputClasses} />
          </div>
          <div>
            <label htmlFor="maintenancePortion" className="block text-sm font-medium text-gray-700">Maintenance Fee Portion</label>
            <input type="number" id="maintenancePortion" value={maintenancePortion} onChange={(e) => setMaintenancePortion(e.target.value)} min="0" step="any" className={formInputClasses} />
          </div>
        </>
      )}

      <div>
        <label htmlFor="expAmount" className="block text-sm font-medium text-gray-700">Total Amount</label>
        <input
          type="number"
          id="expAmount"
          value={amount}
          onChange={(e) => setAmount(e.target.value)}
          required
          min="0"
          step="0.01"
          readOnly={category === ExpenditureCategory.WATER || category === ExpenditureCategory.RENT}
          className={`${formInputClasses} ${(category === ExpenditureCategory.WATER || category === ExpenditureCategory.RENT) ? 'bg-gray-100' : ''}`}
        />
      </div>
      <div>
        <label htmlFor="expDescription" className="block text-sm font-medium text-gray-700">Description</label>
        <textarea id="expDescription" value={description} onChange={(e) => setDescription(e.target.value)} required rows={3} className={formInputClasses} />
      </div>
      
      <div>
        <label htmlFor="paymentMethod" className="block text-sm font-medium text-gray-700">Payment Method (Optional)</label>
        <input type="text" id="paymentMethod" value={paymentMethod} onChange={(e) => setPaymentMethod(e.target.value)} placeholder="e.g., Cash, Bank Transfer" className={formInputClasses} />
      </div>
      <div>
        <label htmlFor="paymentStatus" className="block text-sm font-medium text-gray-700">Payment Status</label>
        <select id="paymentStatus" value={paymentStatus} onChange={(e) => setPaymentStatus(e.target.value as PaymentStatus)} className={`${formInputClasses} bg-white`}>
          {Object.values(PaymentStatus).map(status => (
            <option key={status} value={status}>{status}</option>
          ))}
        </select>
      </div>
       <div className="flex items-center">
        <input id="isRecurring" type="checkbox" checked={isRecurring} onChange={(e) => setIsRecurring(e.target.checked)} className="h-4 w-4 text-primary focus:ring-primary-light border-gray-300 rounded" />
        <label htmlFor="isRecurring" className="ml-2 block text-sm text-gray-900">Is this a recurring expense?</label>
      </div>
      <div className="flex justify-end space-x-3 pt-2">
        <button 
            type="button" 
            onClick={onClose} 
            className="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 hover:bg-gray-200 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-500 transition-colors"
        >
            Cancel
        </button>
        <button 
            type="submit" 
            className="px-4 py-2 text-sm font-medium text-white bg-primary hover:bg-primary-dark border border-transparent rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-dark transition-colors"
        >
            {initialData ? 'Save Changes' : 'Add Expenditure'}
        </button>
      </div>
    </form>
  );
};

export default ExpenditureForm;
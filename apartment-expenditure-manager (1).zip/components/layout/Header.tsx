
import React from 'react';
import { IconMenu, IconDashboard } from '../../constants'; // Using IconDashboard as a generic app icon
import { APP_NAME } from '../../constants';

interface HeaderProps {
  sidebarToggle: () => void;
}

const Header: React.FC<HeaderProps> = ({ sidebarToggle }) => {
  return (
    <header className="bg-white shadow-md p-4 flex items-center justify-between sticky top-0 z-40">
      <div className="flex items-center">
        <button
          onClick={sidebarToggle}
          className="text-gray-600 hover:text-primary focus:outline-none focus:ring-2 focus:ring-primary-light rounded-md p-1 md:hidden"
          aria-label="Toggle sidebar"
        >
          <IconMenu className="h-6 w-6" />
        </button>
        <div className="flex items-center ml-2 md:ml-0">
          <IconDashboard className="h-8 w-8 text-primary" />
          <h1 className="text-xl md:text-2xl font-semibold text-gray-700 ml-2">{APP_NAME}</h1>
        </div>
      </div>
      {/* Placeholder for user profile or other actions */}
      <div>
        {/* <img src="https://picsum.photos/40/40" alt="User Avatar" className="rounded-full" /> */}
      </div>
    </header>
  );
};

export default Header;
    

import React from 'react';
import { NavLink } from 'react-router-dom';
import { IconDashboard, IconTenants, IconExpenditures, IconClose, IconWaterDrop } from '../../constants';

interface SidebarProps {
  isOpen: boolean;
  setIsOpen: (isOpen: boolean) => void;
}

const Sidebar: React.FC<SidebarProps> = ({ isOpen, setIsOpen }) => {
  const navLinkClasses = "flex items-center px-4 py-3 text-gray-700 hover:bg-primary-light hover:text-white rounded-lg transition-colors duration-200";
  const activeNavLinkClasses = "bg-primary text-white";

  const navItems = [
    { to: "/dashboard", icon: <IconDashboard className="h-5 w-5 mr-3" />, label: "Dashboard" },
    { to: "/tenants", icon: <IconTenants className="h-5 w-5 mr-3" />, label: "Tenants" },
    { to: "/expenditures", icon: <IconExpenditures className="h-5 w-5 mr-3" />, label: "Expenditures" },
    { to: "/water-payments", icon: <IconWaterDrop className="h-5 w-5 mr-3" />, label: "Water Payments" },
  ];

  return (
    <>
      {/* Overlay for mobile */}
      {isOpen && (
        <div 
          className="fixed inset-0 z-30 bg-black opacity-50 md:hidden"
          onClick={() => setIsOpen(false)}
        ></div>
      )}

      <aside className={`fixed md:static inset-y-0 left-0 z-40 w-64 bg-white shadow-lg transform ${isOpen ? 'translate-x-0' : '-translate-x-full'} md:translate-x-0 transition-transform duration-300 ease-in-out flex flex-col`}>
        <div className="flex items-center justify-between p-4 border-b md:border-0">
          <span className="text-2xl font-bold text-primary">Menu</span>
          <button onClick={() => setIsOpen(false)} className="md:hidden text-gray-600 hover:text-primary">
            <IconClose className="h-6 w-6" />
          </button>
        </div>
        <nav className="flex-grow p-4 space-y-2">
          {navItems.map(item => (
            <NavLink
              key={item.to}
              to={item.to}
              onClick={() => setIsOpen(false)} // Close sidebar on mobile nav click
              className={({ isActive }) => `${navLinkClasses} ${isActive ? activeNavLinkClasses : ''}`}
            >
              {item.icon}
              {item.label}
            </NavLink>
          ))}
        </nav>
        <div className="p-4 border-t">
          <p className="text-xs text-gray-500 text-center">&copy; {new Date().getFullYear()} MyApartmentApp</p>
        </div>
      </aside>
    </>
  );
};

export default Sidebar;
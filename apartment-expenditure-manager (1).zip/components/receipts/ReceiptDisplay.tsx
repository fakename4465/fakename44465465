import React from 'react';
import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';
import { Expenditure, ExpenditureCategory, PaymentStatus } from '../../types';
import { MANAGER_NAME, WATER_UNIT_COST } from '../../constants'; 

interface ReceiptDisplayProps {
  expenditure: Expenditure;
  tenantName?: string; 
  tenantUnitInfo?: string; 
  issuerName: string; 
  onClose: () => void;
  receiptTitle: string; // Dynamic title (e.g., "Water Bill Receipt", "Rent Receipt")
}

const ReceiptDisplay: React.FC<ReceiptDisplayProps> = ({ expenditure, tenantName, tenantUnitInfo, issuerName, onClose, receiptTitle }) => {
  const receiptId = `RCPT-${expenditure.id.substring(0, 8).toUpperCase()}`;
  const issueDate = new Date().toLocaleDateString();
  const billDate = new Date(expenditure.date).toLocaleDateString();

  const handleGeneratePdf = async () => {
    const receiptElement = document.getElementById('receipt-content');
    if (!receiptElement) {
      console.error("Receipt content element not found!");
      return;
    }
    
    const buttonsToHide = receiptElement.querySelectorAll('.print-hide-in-pdf');
    buttonsToHide.forEach(btn => (btn as HTMLElement).style.display = 'none');

    const canvas = await html2canvas(receiptElement, {
      scale: 2, 
      useCORS: true,
      logging: false,
      onclone: (documentClone) => {
          const clonedReceiptElement = documentClone.getElementById('receipt-content');
          if (clonedReceiptElement) {
              clonedReceiptElement.style.backgroundColor = 'white'; 
              const textElements = clonedReceiptElement.querySelectorAll('p, span, h1, h3, div, td, th');
              textElements.forEach(el => {
                const htmlEl = el as HTMLElement;
                const computedStyle = getComputedStyle(htmlEl);
                if (computedStyle.color === 'rgba(0, 0, 0, 0)' || computedStyle.visibility === 'hidden') {
                    htmlEl.style.color = 'black'; // Ensure text is black
                    htmlEl.style.visibility = 'visible';
                }
                 // Override Tailwind's potential transparent background on some elements in clone
                if (computedStyle.backgroundColor === 'rgba(0, 0, 0, 0)' || computedStyle.backgroundColor === 'transparent') {
                    htmlEl.style.backgroundColor = 'white';
                }
              });
          }
      }
    });

    buttonsToHide.forEach(btn => (btn as HTMLElement).style.display = ''); 

    const imgData = canvas.toDataURL('image/png');
    const pdf = new jsPDF({
      orientation: 'portrait',
      unit: 'pt',
      format: 'a4'
    });

    const pdfWidth = pdf.internal.pageSize.getWidth();
    const pdfHeight = pdf.internal.pageSize.getHeight();
    const canvasWidth = canvas.width;
    const canvasHeight = canvas.height;
    const ratio = canvasWidth / canvasHeight;

    let imgWidth = pdfWidth - 40; 
    let imgHeight = imgWidth / ratio;

    if (imgHeight > pdfHeight - 40) { 
        imgHeight = pdfHeight - 40;
        imgWidth = imgHeight * ratio;
    }
    
    const x = (pdfWidth - imgWidth) / 2;
    const y = 20;

    pdf.addImage(imgData, 'PNG', x, y, imgWidth, imgHeight);
    pdf.save(`${receiptTitle.replace(/\s+/g, '_')}-${tenantName || 'General'}-${receiptId}.pdf`);
  };

  return (
    <div className="text-gray-800">
      <div id="receipt-content" className="p-6 bg-white rounded-lg print-receipt-area">
        <header className="text-center mb-6 border-b pb-4">
          <h1 className="text-3xl font-bold text-primary">{issuerName}</h1>
          <p className="text-gray-500">{receiptTitle}</p>
        </header>

        <div className="grid grid-cols-2 gap-4 mb-6">
          <div>
            <h3 className="font-semibold text-gray-600">Receipt No:</h3>
            <p>{receiptId}</p>
          </div>
          <div className="text-right">
            <h3 className="font-semibold text-gray-600">Date of Issue:</h3>
            <p>{issueDate}</p>
          </div>
          <div>
            <h3 className="font-semibold text-gray-600">Bill Date:</h3>
            <p>{billDate}</p>
          </div>
        </div>

        <div className="mb-6 border-t border-b py-4">
          <h3 className="font-semibold text-gray-600 mb-1">Billed To:</h3>
          {tenantName ? (
            <>
              <p className="text-lg font-medium">{tenantName}</p>
              {tenantUnitInfo && <p className="text-sm text-gray-500">{tenantUnitInfo}</p>}
            </>
          ) : (
            <p>General / Property Expense</p>
          )}
        </div>

        <div className="mb-6">
          <h3 className="font-semibold text-gray-600 mb-2">Charge Details:</h3>
          {expenditure.category === ExpenditureCategory.WATER && (
            <div className="py-2 border-b">
              <div className="flex justify-between items-center">
                <span>{expenditure.description}</span>
                <span className="font-medium">${expenditure.amount.toFixed(2)}</span>
              </div>
              <div className="text-sm text-gray-500 mt-1 space-y-0.5">
                <p>Previous Reading: {expenditure.previousWaterReading?.toFixed(2) ?? 'N/A'}</p>
                <p>Current Reading: {expenditure.currentWaterReading?.toFixed(2) ?? 'N/A'}</p>
                <p>Units Consumed: {expenditure.waterUnitsConsumed?.toFixed(2) ?? 'N/A'} units</p>
                <p>Rate: ${WATER_UNIT_COST.toFixed(2)}/unit</p>
              </div>
            </div>
          )}
          {expenditure.category === ExpenditureCategory.RENT && (
            <div className="space-y-1 py-2 border-b">
              <div className="flex justify-between">
                <span>Base Rent:</span>
                <span>${expenditure.baseRentPortion?.toFixed(2) ?? '0.00'}</span>
              </div>
              {expenditure.maintenancePortion !== undefined && expenditure.maintenancePortion > 0 && (
                <div className="flex justify-between">
                  <span>Maintenance Fee:</span>
                  <span>${expenditure.maintenancePortion.toFixed(2)}</span>
                </div>
              )}
              <div className="flex justify-between font-semibold pt-1 border-t mt-1">
                <span>Total Rent Due:</span>
                <span>${expenditure.amount.toFixed(2)}</span>
              </div>
               <p className="text-sm text-gray-500 mt-1">{expenditure.description}</p>
            </div>
          )}
          {expenditure.category !== ExpenditureCategory.WATER && expenditure.category !== ExpenditureCategory.RENT && (
             <div className="py-2 border-b">
                <div className="flex justify-between items-center">
                    <span>{expenditure.description}</span>
                    <span className="font-medium">${expenditure.amount.toFixed(2)}</span>
                </div>
            </div>
          )}
        </div>
        
        {expenditure.paymentMethod && (
            <div className="mb-4">
                <h3 className="font-semibold text-gray-600">Payment Method:</h3>
                <p>{expenditure.paymentMethod}</p>
            </div>
        )}

        <div className="text-right mb-6">
          <p className="text-sm text-gray-500">Total Amount Paid:</p>
          <p className="text-2xl font-bold text-primary">${expenditure.amount.toFixed(2)}</p>
        </div>

        <div className="text-center py-4 border-t mt-6">
           <p className={`text-xl font-semibold ${
            expenditure.paymentStatus === PaymentStatus.PAID ? 'text-green-600' : 
            expenditure.paymentStatus === PaymentStatus.PENDING ? 'text-yellow-600' : 
            'text-red-600'
          }`}>
            STATUS: {expenditure.paymentStatus?.toUpperCase() || 'UNKNOWN'}
          </p>
          {expenditure.paymentStatus === PaymentStatus.PAID && (
            <p className="text-xs text-gray-500 mt-2">Thank you for your payment.</p>
          )}
        </div>
         <p className="text-xs text-gray-400 text-center mt-4">
            Managed by: {MANAGER_NAME}.
        </p>
      </div>

      <div className="mt-6 flex justify-end space-x-3 print-hide">
        <button
          onClick={onClose}
          className="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 hover:bg-gray-200 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-500"
        >
          Close
        </button>
        {expenditure.paymentStatus === PaymentStatus.PAID && (
            <button
                onClick={handleGeneratePdf}
                className="px-4 py-2 text-sm font-medium text-white bg-primary hover:bg-primary-dark border border-transparent rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-dark print-hide-in-pdf"
            >
                Generate PDF
            </button>
        )}
      </div>
    </div>
  );
};

export default ReceiptDisplay;
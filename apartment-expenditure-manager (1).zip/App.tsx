
import React from 'react';
import { HashRouter, Routes, Route, Navigate } from 'react-router-dom';
import { Tenant, Expenditure } from './types';
import useLocalStorage from './hooks/useLocalStorage';
import Sidebar from './components/layout/Sidebar';
import DashboardPage from './pages/DashboardPage';
import TenantsPage from './pages/TenantsPage';
import ExpendituresPage from './pages/ExpendituresPage';
import Header from './components/layout/Header';
import WaterPaymentsPage from './pages/WaterPaymentsPage'; // Ensured correct relative path

const App: React.FC = () => {
  const [tenants, setTenants] = useLocalStorage<Tenant[]>('tenants', []);
  const [expenditures, setExpenditures] = useLocalStorage<Expenditure[]>('expenditures', []);
  const [isSidebarOpen, setIsSidebarOpen] = React.useState(false);

  const addTenant = (tenant: Omit<Tenant, 'id'>) => {
    const newTenant: Tenant = { ...tenant, id: generateId() };
    setTenants(prev => [...prev, newTenant]);
  };

  const deleteTenant = (tenantId: string) => {
    setTenants(prev => prev.filter(t => t.id !== tenantId));
    // Also delete expenditures associated with this tenant
    setExpenditures(prev => prev.filter(e => e.tenantId !== tenantId));
  };
  
  const updateTenant = (updatedTenant: Tenant) => {
    setTenants(prev => prev.map(t => t.id === updatedTenant.id ? updatedTenant : t));
  };

  const addExpenditure = (expenditure: Omit<Expenditure, 'id'>) => {
    const newExpenditure: Expenditure = { ...expenditure, id: generateId() };
    setExpenditures(prev => [...prev, newExpenditure]);
  };

  const deleteExpenditure = (expenditureId: string) => {
    setExpenditures(prev => prev.filter(e => e.id !== expenditureId));
  };

  const updateExpenditure = (updatedExpenditure: Expenditure) => {
    setExpenditures(prev => prev.map(e => e.id === updatedExpenditure.id ? updatedExpenditure : e));
  };

  const generateId = (): string => {
    return `${Date.now().toString(36)}-${Math.random().toString(36).substring(2, 9)}`;
  };

  return (
    <HashRouter>
      <div className="flex h-screen bg-gray-100 font-sans">
        <Sidebar isOpen={isSidebarOpen} setIsOpen={setIsSidebarOpen} />
        <div className="flex-1 flex flex-col overflow-hidden">
          <Header sidebarToggle={() => setIsSidebarOpen(!isSidebarOpen)} />
          <main className="flex-1 overflow-x-hidden overflow-y-auto bg-gray-100 p-4 md:p-6 lg:p-8">
            <Routes>
              <Route path="/" element={<Navigate to="/dashboard" replace />} />
              <Route path="/dashboard" element={<DashboardPage tenants={tenants} expenditures={expenditures} />} />
              <Route path="/tenants" element={<TenantsPage tenants={tenants} addTenant={addTenant} deleteTenant={deleteTenant} updateTenant={updateTenant} />} />
              <Route path="/expenditures" element={<ExpendituresPage expenditures={expenditures} addExpenditure={addExpenditure} deleteExpenditure={deleteExpenditure} updateExpenditure={updateExpenditure} tenants={tenants} />} />
              <Route path="/water-payments" element={<WaterPaymentsPage expenditures={expenditures} tenants={tenants} updateExpenditure={updateExpenditure} />} />
            </Routes>
          </main>
        </div>
      </div>
    </HashRouter>
  );
};

export default App;